import "./component.css"
import Navigator from "./Navigator";
import Header from "./Header";

export { Navigator, Header }